from warn.warn import *
# -*- coding: utf-8 -*-
def bnr():
 print (f"""
{ken}    ______   _______     _       ____    ____  
{kon}  .' ____ \ |_   __ \   / \     |_   \  /   _| 
{ken}  | (___ \_|  | |__) | / _ \      |   \/   |   
{kon}   _.____`.   |  ___/ / ___ \     | |\  /| |   
{ken}  | \____) | _| |_  _/ /   \ \_  _| |_\/_| |_  
{kon}   \______.'|_____||____| |____||_____||_____| 
       {im}╔═╗┬  ┬{anj}    {im}╔═╗┌─┐┬─┐  {anj}╔═╗┌┐┌┌─┐
       {anj}╠═╣│  │{im}    {anj}╠╣ │ │├┬┘  {im}║ ║│││├┤ 
       {im}╩ ╩┴─┘┴─┘{anj}  {im}╚  └─┘┴└─  {anj}╚═╝┘└┘└─┘
{im}••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••
{kun}[$] Author : {kin}Mr-S4NTUY
{kun}[$] Nama SC : {kin}Spam Brutal
{kun}[$] Github : {kin}https://github.com/Mr-S4NTUY
{kun}[$] Youtube : {kin}TUTORIAL ANDROID
{im}••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••""")
